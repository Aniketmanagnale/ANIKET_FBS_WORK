package p1;
import java.util.Date;
public abstract class Account {
	String accountHolderName;
	protected int accountNumber;
	String accountType;
	double currentBalance;
	String panNumber;
	String aadharNumber;
	String contactNumber;
	
	protected int transCount;
	static protected int transId;
	
	
	protected Transaction [] transactions = new Transaction[100];
	static {
		transId = 0;
	}
	public Account() {
		this.accountHolderName = "Dhananjay Sangle";
		this.accountNumber = 101;
		this.accountType = "Saving account";
		this.currentBalance = 10000;
		this.panNumber = "ABCDE1234F";
		this.aadharNumber = "1234-5678-9012";
		this.contactNumber = "9876543210";

	}
	
	public Account(String accountHolderName, int accNo, String accountType, double currentBalance, String panNumber,
		String aadharNumber, String contactNumber) {
		this.accountHolderName = accountHolderName;
		this.accountNumber = accNo;
		this.accountType = accountType;
		this.currentBalance = currentBalance;
		this.panNumber = panNumber;
		this.aadharNumber = aadharNumber;
		this.contactNumber = contactNumber;
		//this.transactions = new Transaction[100];
	}

	String getAccountHolderName() {
		return accountHolderName;
	}

	void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	int getAccountNumber() {
		return accountNumber;
	}

	void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	String getAccountType() {
		return accountType;
	}

	void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	protected double getCurrentBalance() {
		return currentBalance;
	}

	protected void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	String getPanNumber() {
		return panNumber;
	}

	void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	String getAadharNumber() {
		return aadharNumber;
	}

	void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	String getContactNumber() {
		return contactNumber;
	}

	void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	 

	public String toString() {
		return "Account Holder : "+this.accountHolderName + "\n" + "Account Number : "+this.accountNumber + "\n" 
				+"Account Type : "+this.accountType + "\n" +"Balance : "+this.currentBalance +"\n"+"PAN Number : " +this.panNumber +
				"\n" + "Aadhar Number : "+this.aadharNumber + "\n" +"Contact : "+this.contactNumber + "\n";
	}
	
	public abstract void withdraw(double amount);
	
	public abstract void calculateInterest(int year);
	
	public void deposit(double amount) {
		currentBalance = currentBalance + amount;
		System.out.println("Deposited Successfully");
		   
		    	if(transCount < transactions.length)
 		        transactions[transCount++] = new Transaction(transCount++, new Date(), "Deposit", amount, this.accountNumber);
		          
		     
	}	    		
		

		
	public double checkBalance() {
		return currentBalance;
	}
	
	
	//TransferMoney method
	
	public boolean transferMoney(Account receiver,double amount) {
		if (currentBalance <= 0) {
			System.out.println("Invalid transfer amount ");
			return false;
		}
		
		if(receiver == null) {
			System.out.println("Account not exits");
			return false;
		}
		
		if (this.currentBalance < amount) {
			System.out.println("Insufficient balance.");
			return false;
		}
		
		this.currentBalance = this.currentBalance - amount;
		receiver.currentBalance = receiver.currentBalance + amount;
		
		if(this.transCount < transactions.length)
		this.transactions [this.transCount++] = new Transaction(transId++,new Date(),"Transfer out",amount,this.accountNumber);
		
		
		
		if(receiver.transCount < receiver.transactions.length)
		receiver.transactions [receiver.transCount++] = new Transaction(transId++,new Date(),"Transfer in",amount,receiver.accountNumber);
 		return true;
	}
	
	public void endOfDayReport() {
        System.out.println("\n--- Transaction Report for Account " + accountNumber + " ---");
        if (transCount == 0) {
            System.out.println("No transactions found.");
            return;
        }
        for (int i = 0; i < transCount; i++) {
        	   if (transactions[i] != null) {
                    transactions[i].getRecord();   
                    System.out.println();
               }
        }
    }
}


