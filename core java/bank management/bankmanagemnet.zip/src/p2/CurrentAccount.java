package p2;

import java.util.Date;
import p1.Account;
 import p1.Transaction;

public class CurrentAccount extends Account{
	double overDraftLimit;
	double overDraftBalance;
	String businessName;
	boolean isFrozen;
	double interestRate;
	double overDraftRate;
	
	CurrentAccount() {
		super();
		this.overDraftLimit = 50000;
		this.overDraftBalance = 20000;
		this.businessName = "Dairy";
		this.isFrozen = false;
		this.interestRate=0.03;
		this.overDraftRate=0.05;
	}

	public CurrentAccount(String accountHolderName, int accNo, String accountType, double currentBalance, String panNumber,
			String aadharNumber, String contactNumber,double overDraftLimit, double overDraftBalance, String businessName, boolean isFrozen,double interesetRate, double interestRate,double overDraftRate) {
		super(accountHolderName,accNo,accountType,currentBalance,panNumber,aadharNumber,contactNumber);
		this.overDraftLimit = overDraftLimit;
		this.overDraftBalance = overDraftBalance;
		this.businessName = businessName;
		this.isFrozen = isFrozen;
		this.interestRate=interestRate;
	}

	double getOverDraftLimit() {
		return overDraftLimit;
	}

	void setOverDraftLimit(double overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}

	double getOverDraftBalance() {
		return overDraftBalance;
	}

	void setOverDraftBalance(double overDraftBalance) {
		this.overDraftBalance = overDraftBalance;
	}

	String getBusinessName() {
		return businessName;
	}

	void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	boolean isFrozen() {
		return isFrozen;
	}

	void setFrozen(boolean isFrozen) {
		this.isFrozen = isFrozen;
	}
	

	double getInterestRate() {
		return interestRate;
	}

	void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	
	double getOverDraftRate() {
		return overDraftRate;
	}

	void setOverDraftRate(double overDraftRate) {
		this.overDraftRate = overDraftRate;
	}

	public String toString() {
	
		return super.toString() + "OverDraft Limit : "+this.overDraftLimit+"\n"+"OverDraft Balance : "+this.overDraftBalance+"\n"+
		"Business Name : "+this.businessName+"\n"+"IsFrozen : "+this.isFrozen+"\n";
	}
 
 

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		
		if(amount > getCurrentBalance() + overDraftLimit) {
			System.out.println("Overdraft limit exceeded !");
			return;
 		}
		 
		double balance= getCurrentBalance();
			 balance = balance - amount;
			 
		if (transCount < transactions.length) {
			transactions[transCount] = new Transaction (transId++,new Date(),"withdraw",amount,this.accountNumber);
			transCount++;
			System.out.println();
		}
	}

	@Override
	public void calculateInterest(int year) {
		// TODO Auto-generated method stub 
		   if (getCurrentBalance() > 0) {
	            double interest = getCurrentBalance() * interestRate * year;
	            System.out.println("Interest on positive balance for " + year + " years: ₹"+interest);
	            setCurrentBalance(getCurrentBalance() + interest); 
	        }
		   
		   else if (getCurrentBalance() < 0) {
	            double interest = -getCurrentBalance() * overDraftRate * year;
	            System.out.println("Overdraft interest for " + year + " years: ₹" +  interest);
	            setCurrentBalance(getCurrentBalance() - interest);  
	        } 
		   
		   else {
	            System.out.println("No interest. Balance is zero.");
	        }
	}
	
	 
	
}
