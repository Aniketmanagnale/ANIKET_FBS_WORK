package p2;

import java.util.Date;

import p1.Account;
import p1.Transaction;

public class LoanAccount extends Account{
	double loanAmount;
	double paidAmount;
	double remainingAmount;
	double monthlyEMI;
	boolean isFrozen;
	String loanType;
	LoanAccount() {
		super();
		this.loanAmount = 50000;
		this.paidAmount = 20000;
		this.remainingAmount = 30000;
		this.isFrozen = false;
		this.loanType = "Personal Loan";
		this.monthlyEMI = 2000;
	}
	
	public LoanAccount(String accountHolderName, int accNo, String accountType, double currentBalance, String panNumber,
			String aadharNumber, String contactNumber,double loanAmount, double paidAmount, double remainingAmount, boolean isFrozen,String loanType,double monthlyEMI) {
		super(accountHolderName,accNo,accountType,currentBalance,panNumber,aadharNumber,contactNumber);
		this.loanAmount = loanAmount;
		this.paidAmount = paidAmount;
		this.remainingAmount = remainingAmount;
		this.isFrozen = isFrozen;
		this.loanType = loanType;
		this.monthlyEMI=monthlyEMI;
	}

	double getLoanAmount() {
		return loanAmount;
	}

	void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	double getPaidAmount() {
		return paidAmount;
	}

	void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}

	double getRemainingAmount() {
		return remainingAmount;
	}

	void setRemainingAmount(double remainingAmount) {
		this.remainingAmount = remainingAmount;
	}

	boolean isFrozen() {
		return isFrozen;
	}

	void setFrozen(boolean isFrozen) {
		this.isFrozen = isFrozen;
	}
	
	void setloanType (String loanType) {
		this.loanType = loanType;
	}
	
	String getLoanType () {
		return loanType;
	}
	
	
	double getMonthlyEMI() {
		return monthlyEMI;
	}

	void setMonthlyEMI(double monthlyEMI) {
		this.monthlyEMI = monthlyEMI;
	}

	void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "Loan Amount : "+this.loanAmount+"\n"+"Paid Amount : "+this.paidAmount+"\n"+"Remaining Amount : "+this.remainingAmount
				+"\n"+"Is Frozen : "+this.isFrozen+"\n";
	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		System.out.println("Withdraw not allowed for load account");
		
	}

	@Override
	public void calculateInterest(int years) {
		// TODO Auto-generated method stub
		double annualInterestRate;
		
		if (loanType.equals("Personal Loan")) {
		    annualInterestRate = 0.10;  
		} else if (loanType.equals("Home Loan")) {
		    annualInterestRate = 0.08; 
		} else if (loanType.equals("Vehicle Loan")) {
		    annualInterestRate = 0.09;  
		} else if (loanType.equals("Education Loan")) {
		    annualInterestRate = 0.08; 
		} else {
		    annualInterestRate = 0.13;  
		}
		
		  double monthlyInterestRate = annualInterestRate / 12;
	        int totalMonths = years * 12;
 
	        monthlyEMI = (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths))
	            / (Math.pow(1 + monthlyInterestRate, totalMonths) - 1);

	        double currentBalance = monthlyEMI * totalMonths;
	        setCurrentBalance(currentBalance);
 	 	 
	}
	
	public void payEmI (double amount) {
		if(isFrozen) {
			System.out.println("Account is frozen. Cannot pay EMI.");
			return;
		}
		
		if (amount <= 0) {
			System.out.println("Invalid EMI amount");
			return;
		}
		
		if (remainingAmount <= 0) {
			System.out.println("Loan already fully paid !");
			return;
		}
		
		if (amount > remainingAmount) {
			amount = remainingAmount;
		}
		
		paidAmount = paidAmount + amount;
		remainingAmount = remainingAmount - amount;
		
		setCurrentBalance(remainingAmount);
		System.out.println("Emi of " + amount +  "paid successfully");
		System.out.println("Paid Amount : "+paidAmount);
		System.out.println("Remaining Amount : "+remainingAmount);
		
		if(transCount < transactions.length) {
			transactions[transCount] = new Transaction (transId++,new Date(),"payEmi",amount,this.accountNumber);
			transCount++;
			System.out.println();
		}
		else {
			System.out.println("Array is full");
		}
		
	}
	
	public void checkLoanStatus () {
		if (remainingAmount == 0) {
			System.out.println("Status : Fully paid");
		}
		else {
			System.out.println("Status : Remaining");
		}
	}
	
}
