package p2;

import java.util.Date;

import p1.Account;
import p1.Transaction;

public class SalaryAccount extends Account {
		double salaryAmount;
		double bonus;
		
		SalaryAccount() {
			super();
			this.salaryAmount = 75000;
			this.bonus = 5000;
		}
		
		public SalaryAccount(String accountHolderName, int accNo, String accountType, double currentBalance, String panNumber,
				String aadharNumber, String contactNumber,double salaryAmount, double bonus) {
			super(accountHolderName,accNo,accountType,currentBalance,panNumber,aadharNumber,contactNumber);
			this.salaryAmount = salaryAmount;
			this.bonus = bonus;
		}

		double getSalaryAmount() {
			return salaryAmount;
		}

		void setSalaryAmount(double salaryAmount) {
			this.salaryAmount = salaryAmount;
		}

		double getBonus() {
			return bonus;
		}

		void setBonus(double bonus) {
			this.bonus = bonus;
		}
		
		@Override
		public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+"Salary Amount : "+this.salaryAmount+"\n"+"Bonus "+this.bonus+"\n";
		}
 

		@Override
		public void calculateInterest(int year) {
			double interest = getCurrentBalance() * 0.03 * year;
		    System.out.println("Interest for " + year + " years: ₹" +  interest);
		    
		}

		@Override
		public void withdraw(double amount) {
			// TODO Auto-generated method stub
			if(getCurrentBalance() >= amount ) {
				 setCurrentBalance(getCurrentBalance()-amount);
				 System.out.println("Withdraw succefully!");
			}
			else {
				System.out.println("Insufficient balance");
			}
			if (transCount < transactions.length) {
				transactions[transCount] = new Transaction(transId++,new Date(),"with",amount,this.accountNumber);
				transCount++;
				System.out.println();
			}
			else {
				System.out.println("Array is full");
			}
		}
		
		public void creditSalary() {
			double totalSalary = salaryAmount + bonus;
			setCurrentBalance (getCurrentBalance()+totalSalary);
			System.out.println("Salary credited : "+totalSalary);
			System.out.println("Current balance : "+getCurrentBalance());
			if (transCount < transactions.length) {
				transactions[transCount] = new Transaction(transId++,new Date(),"Credit",totalSalary,this.accountNumber);
				transCount++;
				System.out.println();
			}
			else {
				System.out.println("Array is full");
			}
		}
	
}
