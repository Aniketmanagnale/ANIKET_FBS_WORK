package p2;

import java.util.Date;

import p1.Account;
import p1.Transaction;

public class SavingAccount extends Account {
	double minBalance;
	float tdInterest;
	double withdrawLimit;
	boolean isFrozen;
	double fdAmount;
	double fdYears;
	
	double getFdAmount() {
		return fdAmount;
	}

	void setFdAmount(double fdAmount) {
		this.fdAmount = fdAmount;
	}

	double getFdYears() {
		return fdYears;
	}

	void setFdYears(double fdYears) {
		this.fdYears = fdYears;
	}

	SavingAccount() {
		super();
		this.minBalance = 30000;
		this.tdInterest = 7;
		this.withdrawLimit = 5000;
		this.isFrozen = false;
	}
	
	public SavingAccount(String accountHolderName, int accNo, String accountType, double currentBalance, String panNumber,
			String aadharNumber, String contactNumber,double minBalance, float tdInterest, double withdrawLimit, boolean isFrozen) {
		super(accountHolderName,accNo,accountType,currentBalance,panNumber,aadharNumber,contactNumber);
		this.minBalance = minBalance;
		this.tdInterest = tdInterest;
		this.withdrawLimit = withdrawLimit;
		this.isFrozen = isFrozen;
	}

	double getMinBalance() {
		return minBalance;
	}

	void setMinBalance(double minBalance) {
		this.minBalance = minBalance;
	}

	float getTdInterest() {
		return tdInterest;
	}

	void setTdInterest(float tdInterest) {
		this.tdInterest = tdInterest;
	}

	double getWithdrawLimit() {
		return withdrawLimit;
	}

	void setWithdrawLimit(double withdrawLimit) {
		this.withdrawLimit = withdrawLimit;
	}

	boolean isFrozen() {
		return isFrozen;
	}

	void setFrozen(boolean isFrozen) {
		this.isFrozen = isFrozen;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
        return super.toString() +
                "Minimum Balance: ₹" + minBalance + "\n" + 
                "FD Amount: ₹" + fdAmount + " for " + fdYears + " years\n";

	}
 
	  public boolean checkMinBalance() {
	        if (getCurrentBalance() < minBalance) {
	            System.out.println("Balance below minimum of " + minBalance);
	            return false;
	        } else {
	            System.out.println("Minimum balance maintained: " + getCurrentBalance());
	            return true;
	        }
	    }

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		  if (amount <= 0) {
	            System.out.println("Invalid withdrawal amount.");
	            return;
	        }

	        if (getCurrentBalance() - amount < minBalance) {
	            System.out.println("Cannot withdraw. Minimum balance of ₹" + minBalance + " must be maintained.");
	            return;
	        }

	        setCurrentBalance(getCurrentBalance() - amount);
	        System.out.println(" Withdrawal successful. Current Balance: ₹" +  getCurrentBalance());
	        
	    	if (transCount < transactions.length) {
				transactions[transCount] = new Transaction(transId++,new Date(),"withdraw",amount,this.accountNumber);
				transCount++;
				System.out.println();
	    	}
			else {
				System.out.println("Array is full");
			}
	}

	@Override
	public void calculateInterest(int year) {
		// TODO Auto-generated method stub
        if (getCurrentBalance() > 0) {
            double balanceInterest = getCurrentBalance() * tdInterest * year;
            setCurrentBalance(getCurrentBalance() + balanceInterest);
            System.out.println("Interest on balance for " + year + " years: ₹" +  balanceInterest);
        }

        if (fdAmount > 0) {
            double fdInterestRate = 0.07; 
            double fdInterest = fdAmount * fdInterestRate * fdYears;
            System.out.println("FD Interest for " + fdYears + " years: ₹" +  fdInterest);
        }
		
	}
	
	 public void openFD(double amount, int year) {
	        if (amount <= 0 || year <= 0) {
	            System.out.println("Invalid FD amount or tenure.");
	            return;
	        }

	        if (getCurrentBalance() - amount < minBalance) {
	            System.out.println("Cannot open FD. Minimum balance of ₹" + minBalance + " must be maintained.");
	            return;
	        }

	        fdAmount = amount;
	        fdYears = year;
	        setCurrentBalance(getCurrentBalance() - amount);
	        System.out.println("FD opened: ₹" + amount + " for " + year + " years.");
	    }
}
