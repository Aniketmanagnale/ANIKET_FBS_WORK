package view;

import p1.Account;
import p1.Bank;
import p2.LoanAccount;
import p2.SalaryAccount;
import p2.SavingAccount;
import java.util.*;

public class MainBankApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bank bank = new Bank();
         
        while (true) {
            System.out.println("\n=======  BANK MENU =======");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer Money");
            System.out.println("5. Calculate Interest");
            System.out.println("6. Credit Salary");
            System.out.println("7. Pay EMI");
            System.out.println("8. Open FD");
            System.out.println("9. Check Loan Status");
            System.out.println("10. Display All Accounts");
             System.out.println("11. End of Day Report");
            System.out.println("0. Exit");
            System.out.println("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 0:
                    System.out.println("Exiting Bank System. Goodbye!");
                    return;

                case 1:
                    bank.createAccount(sc);
                    break;

                case 2: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc == null) {
                        System.out.println("Account not found!");
                        break;
                    }
                    System.out.println("Enter amount: ");
                    acc.deposit(sc.nextDouble());
                    break;
                }

                case 3: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc == null) {
                        System.out.println("Account not found!");
                        break;
                    }
                    System.out.println("Enter amount: ");
                    acc.withdraw(sc.nextDouble());
                    break;
                }

                case 4: {
                    System.out.println("Enter Sender Account No: ");
                    int senderNo = sc.nextInt();
                    Account sender = bank.getAccount(senderNo);
                    if (sender == null) {
                        System.out.println("Sender account not found!");
                        break;
                    }
                    System.out.println("Enter Receiver Account No: ");
                    int recvNo = sc.nextInt();
                    Account receiver = bank.getAccount(recvNo);
                    System.out.println("Enter amount: ");
                    double amt = sc.nextDouble();
                    sender.transferMoney(receiver, amt); // internally handles receiver==null
                    break;
                }

                case 5: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc == null) {
                        System.out.println("Account not found!");
                        break;
                    }
                    System.out.println("Enter years: ");
                    acc.calculateInterest(sc.nextInt());
                    break;
                }

                case 6: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc instanceof SalaryAccount)
                        ((SalaryAccount) acc).creditSalary();
                    else
                        System.out.println("Not a Salary Account or Account not found!");
                    break;
                }

                case 7: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc instanceof LoanAccount) {
                        System.out.print("Enter EMI Amount: ");
                        ((LoanAccount) acc).payEmI(sc.nextDouble());
                    } else
                        System.out.println("Not a Loan Account or Account not found!");
                    break;
                }

                case 8: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc instanceof SavingAccount) {
                        System.out.println("Enter FD Amount: ");
                        double amt = sc.nextDouble();
                        System.out.println("Enter FD Years: ");
                        int yrs = sc.nextInt();
                        ((SavingAccount) acc).openFD(amt, yrs);
                    } else
                        System.out.println("Not a Saving Account or Account not found!");
                    break;
                }

                case 9: {
                    System.out.println("Enter Account No: ");
                    int accNo = sc.nextInt();
                    Account acc = bank.getAccount(accNo);
                    if (acc instanceof LoanAccount)
                        ((LoanAccount) acc).checkLoanStatus();
                    else
                        System.out.println("Not a Loan Account or Account not found!");
                    break;
                }

                case 10:
                    bank.displayAllAccounts();
                    break;
 
                case 11: {
                    System.out.println("Enter Account No: ");
                    int accNo1 = sc.nextInt();
                    Account acc1 = bank.getAccount(accNo1);
                    if (acc1 != null)
                        acc1.endOfDayReport();
                    else
                        System.out.println("Account not found!");
                    break;
                }

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
