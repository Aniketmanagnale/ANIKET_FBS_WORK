package employee.comparator;

import java.util.Comparator;

import employee.model.Employee;

public class EmployeeComparator implements Comparator<Employee>{
	OrderEnum order;
	String attribute;
	
	public EmployeeComparator(OrderEnum order, String attribute) {
 		this.order = order;
		this.attribute = attribute;
	}


	@Override
	public int compare(Employee o1, Employee o2) {
		 if(this.order.equals(order.ASC))
		 {
			 if(this.attribute.equals("salary"))
				 return (int) (o1.getSalary()-o2.getSalary());
			 else if(this.attribute.equals("name"))
				 return o1.getEmpName().compareTo(o2.getEmpName());
			 else 
				 return o1.getEmpId()-o2.getEmpId();
			 
		 }
		 else {
			 if(this.attribute.equals("salary"))
				 return (int) (o2.getSalary()-o1.getSalary());
			 else if(this.attribute.equals("name"))
				 return o2.getEmpName().compareTo(o1.getEmpName());
			 else 
				 return o2.getEmpId()-o1.getEmpId();

		 }
		 
	}
	
	
}
