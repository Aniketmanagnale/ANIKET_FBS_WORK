package employee.comparator;

public enum OrderEnum {
	ASC,DSC;
}
