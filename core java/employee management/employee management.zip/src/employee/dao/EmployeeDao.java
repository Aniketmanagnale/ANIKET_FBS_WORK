package employee.dao;
import java.util.ArrayList;
import java.util.Collections;
import employee.comparator.OrderEnum;
import employee.comparator.EmployeeComparator;
import employee.model.*;
 

public class EmployeeDao {
	static  ArrayList<Employee> employees = new ArrayList <Employee> ();;
 	
	static {
		 
		employees.add(new HRManager(101, "Ranjit", 50000, 5000));
	    employees.add( new HRManager(102, "Amit", 48000, 4500));
	    employees.add (new HRManager(103, "Sneha", 47000, 4000));
	    employees.add (new SalesManager(201, "Karan", 60000, 12, 8000));
	    employees.add (new SalesManager(202, "Meena", 58000, 15, 7500));
	    employees.add (new SalesManager(203, "Rohit", 62000, 10, 9000));
	    employees.add (new Admin(301, "Pragati", 70000, 10000));
	    employees.add (new Admin(302, "Isha", 68000, 9500));
	    employees.add (new Admin(303, "Pooja", 72000, 11000));
	    employees.add (new Admin(304, "Shubham", 75000, 12000));
	}
	
	public void addEmployee (Employee e) {
			 employees.add(e);
	}
	
	public Employee searchEmployeeById (int id) {
		
		for (int i=0;i<employees.size()-1;i++) {
		if (employees.get(i).getEmpId() == id) 
			return employees.get(i);
		}
		return null;
	}
	
	public Employee updateEmployeeSalary(int id,double salary) {
		for (int i = 0;i < employees.size()-1;i++) {
			if(employees.get(i).getEmpId() == id) {
				employees.get(i).setSalary(salary);
				return employees.get(i);
 			}
		}
		return null;
	}
 

	public ArrayList<Employee> displayAllEmployees () {
 			 return employees;

	}

	  public int deleteEmployee(int id) {
		  
		  for (int i = 0;i < employees.size()-1;i++) {
 				if(employees.get(i).getEmpId() == id) {
						 employees.remove(i);	
						return 1;
				}
		  }
		  return 0;
	  }
	  
	  public void sortEmoployee(String attribute,OrderEnum order) {
 		  Collections.sort(employees,new EmployeeComparator(order,attribute));
	  }
	  
	  public static int getEmpCount() {
		  return  employees.size()-1;
	  }

	  
}
