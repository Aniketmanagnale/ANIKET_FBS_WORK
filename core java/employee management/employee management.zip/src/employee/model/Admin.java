package employee.model;
 

public class Admin extends Employee {
	double allowance;

	public Admin() {
		super();
		this.allowance=6000;
	}

	public Admin(int empId,String name,double salary,double allowance) {
		super(empId,name,salary);
		this.allowance = allowance ;
	}

	public double getallowenc() {
		return allowance;
	}

	public void setallowenc(double allowance) {
		this.allowance = allowance;
	}
	
	public double calcSal () {
		return getSalary()+allowance;
	}
 

	public String toString() {
	
		return super.toString() + "\n"+ "Allowance : "+this.allowance + "\n"+ "Total salary : "+this.calcSal()+ "\n\n";
	}
}
