package employee.model;

abstract public class Employee {
	int empId;
	String empName;
	 double salary;
	public Employee() {    
		this.empId=101;
		this.empName="Dhananjay";
		this.salary=20000;
			}
	public Employee(int emp_id, String emp_name, double salary) {
		super();
		this.empId = emp_id;
		this.empName = emp_name;
		this.salary = salary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	abstract public double calcSal ();
 
	
	@Override
	public String toString() {
		return "Employee ID : "+this.empId+ "\n" + "Employee Name : "
	+this.empName+ "\n" +"Salary : "+this.salary ;
	}
	
}
