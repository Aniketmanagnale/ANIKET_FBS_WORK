package employee.model;



public class HRManager  extends Employee{
	double commition;

	public HRManager() {
		super();
		this.commition=2000;
	}

	public HRManager(int empId,String name,double salary,double commition) {
		super(empId,name,salary);
		this.commition = commition;
	}

	public double getCommition() {
		return commition;
	}
	public double calcSal () {
		return getSalary()+commition;
	}
	public void setCommition(double commition) {
		this.commition = commition;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "\n"+"Commition : "+this.commition + "\n"
				+ "Total salary : "+ 
				this.calcSal()+ "\n\n";
	}
	
}
