package employee.model;


public class SalesManager extends Employee{
	double insentive;
	int target;
	public SalesManager() {
		super();
		this.insentive=2.5;
		this.target=10;
	}
	public SalesManager(int empId,String name,double salary,double insentive, int target) {
		super(empId,name,salary);
		this.insentive = insentive;
		this.target = target;
	}
	public double getIncentiv() {
		return insentive;
	}
	public void setIncentiv(double insentive) {
		this.insentive = insentive;
	}
	public int getTarget() {
		return target;
	}
	public void setTarget(int target) {
		this.target = target;
	}
	
	public double calcSal () {
		return getSalary()+insentive;
	}
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "\n"+ "Insentive : "+ "\n"+this.insentive+ "\n" 
				+"Target : "+this.target + "\n"+ "Total salary : "+this.calcSal()+ "\n\n";
	}
}
