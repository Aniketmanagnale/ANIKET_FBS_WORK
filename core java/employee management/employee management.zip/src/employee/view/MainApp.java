package employee.view;
import employee.model.*;

import java.util.ArrayList;
import java.util.Scanner;

import employee.comparator.OrderEnum;
import employee.dao.EmployeeDao;
 


public class MainApp {
	public static void main (String [] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeDao dao = new EmployeeDao ();
		 
	    int choice;
        do {
            System.out.println("\n====== Employee Management System ======");
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee by ID");
            System.out.println("3. Update salary of Employee");
            System.out.println("4. Delete Employee by ID");
            System.out.println("5. Display All Employees");
            System.out.println("6. Sort Employees");
            System.out.println("7  Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            System.out.println();

            switch (choice) {
                case 1:
                	System.out.println("Select employee type to add : ");
                	System.out.println("1 HRManager"+"\n"+"2 SalesManager"+"\n"+"3 Admin");
                	int type = sc.nextInt();
                		
                	System.out.println("Enter the Id : ");
                    int id = sc.nextInt();
                	sc.nextLine();
                	System.out.println("Enter the name : ");
                	String name = sc.nextLine();
                	System.out.println("Enter the salary : ");
                	double salary = sc.nextDouble();
                	
                	if (type == 1) {                	               		
                		System.out.println("Enter the commission ");
                		double commission = sc.nextDouble();
                		dao.addEmployee(new HRManager (id,name,salary,commission));
                		System.out.println("HRManager added succesfully !!");
                	}
                	else if (type == 2) {
                		System.out.println("Enter the insentive ");
                		double insentive = sc.nextDouble();
                		System.out.println("Enter the target ");
                		int target = sc.nextInt();
                		dao.addEmployee(new SalesManager (id,name,salary,insentive,target));
                		System.out.println("SalesManager added successfully !!");
                	}
                	else if (type == 3) {
                		System.out.println("Enter the allowance ");
                		double allowance = sc.nextDouble();
                		dao.addEmployee(new Admin (id,name,salary,allowance));
                		System.out.println("Admin added successfully !!");
                	}
                	else {
                		System.out.println("Invalid choice !");
                	}
                    break;
                case 2:
                    System.out.println("Enter the id ");
                    int id1 = sc.nextInt();
                    
                    Employee e =  dao.searchEmployeeById(id1);
                    if (e != null) {
                    	System.out.println(" Found !" +"\n"+ e);
                    }
                    else {
                    	System.out.println("Not found ");
                    }
                    break;
                case 3:
                    System.out.println("Enter the id to update ");
                    int id2 = sc.nextInt();
                    System.out.println("Enter the new salary ");
                    double salary1 = sc.nextDouble();
                    Employee e1 =  dao.updateEmployeeSalary(id2,salary1);
                    if (e1 != null) {
                    	System.out.println( e1);
                    	System.out.println("Updated successfully !");
                    }
                    else {
                    	System.out.println("Not found ");
                    }
                    break;
                case 4:
                    System.out.println("Enter the id to delete ");
                    int id3 = sc.nextInt();
                    int deleteEmployee = dao.deleteEmployee(id3);
                    if (deleteEmployee == 1) {
                    	System.out.println("Deleted successfully !");
                    }
                    else {
                    	System.out.println("Not found ");
                    }
                    break;
                case 5:
                	ArrayList <Employee> employees = dao.displayAllEmployees();
                	System.out.println(employees);
                     break;
                case 6:
                	System.out.println("Enter the 1 to sort low to high");
                	System.out.println("Enter the 2 to sort high to low");
                	int subChoice = sc.nextInt();
                	
                	switch(subChoice) {
                	case 1:
                		dao.sortEmoployee("salary",OrderEnum.ASC);
                		break;
                	case 2:
                		dao.sortEmoployee("salary", OrderEnum.DSC);
                		break;
                		default:
                			System.out.println("Enter the valid choice");
                			break;
                	}
                	
                	break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
 
        } while (choice != 7);
		
	}
}
